-- ************** Menu ********************
--       ***** use mapping******
truncate table ticketing_user_group_master;
create table ticketing_user_group_master(
	ugrp_code int primary key,
    ugrp_desc varchar(50),
	created_by	varchar(50),
	created_time date,
	modified_by	varchar(50),
	modified_time date
);
insert into ticketing_user_group_master values('1', 'Software Engineer', '9082203001', curdate(), NULL, NULL);
insert into ticketing_user_group_master values('2', 'Asset Management', '9082203001', curdate(), NULL, NULL); -- Admin
insert into ticketing_user_group_master values('3', 'End User Support', '9082203001', curdate(), NULL, NULL);

select * from ticketing_user_group_groupwise;
truncate table ticketing_user_group_groupwise;
create table ticketing_user_group_groupwise(
	userid varchar(30) primary key,
	ugrp_code int,
	created_by	varchar(50),
	created_time date,
	modified_by	varchar(50),
	modified_time date
);

insert into ticketing_user_group_groupwise values('9082202001', '1', '9082203001', curdate(), NULL, NULL);
insert into ticketing_user_group_groupwise values('9082203001', '1', '9082203001', curdate(), NULL, NULL);
insert into ticketing_user_group_groupwise values('9080701007', '2', '9082203001', curdate(), NULL, NULL);
insert into ticketing_user_group_groupwise values('9082208005', '2', '9082203001', curdate(), NULL, NULL); --  hussain


--       ***** program mapping******
select * from ticketing_program_master;
create table ticketing_program_master(
	program_code int primary key,
	program_description	varchar(100),
	program_name varchar(100),
	program_print int,
	program_order int,
	created_by	varchar(50),
	created_time date,
	modified_by	varchar(50),
	modified_time date
);
truncate table ticketing_program_master;
insert into ticketing_program_master
values('10', 'New Ticket', 'newTicket.jsp', null, null, '9082203001', curdate(), NULL, NULL);
insert into ticketing_program_master
values('20', 'Modify Ticket', 'modifyTicket.jsp', null, null, '9082203001', curdate(), NULL, NULL);

insert into ticketing_program_master
values('30', 'Admin', '#', null, null, '9082203001', curdate(), NULL, NULL);
insert into ticketing_program_master
values('3001', 'User Mapping', 'userGroupMaster.jsp', '30', '1', '9082203001', curdate(), NULL, NULL);

truncate table ticketing_program_groupwise;
create table ticketing_program_groupwise(
	ugrp_code int,
	program_code int,
	created_by	varchar(50),
	created_time date,
	modified_by	varchar(50),
	modified_time date
);

insert into ticketing_program_groupwise values('1', '10', '9082203001',curdate(), null, null);
insert into ticketing_program_groupwise values('2', '10', '9082203001',curdate(), null, null);
insert into ticketing_program_groupwise values('2', '20', '9082203001',curdate(), null, null);
insert into ticketing_program_groupwise values('2', '30', '9082203001',curdate(), null, null);
insert into ticketing_program_groupwise values('2', '3001', '9082203001',curdate(), null, null);


