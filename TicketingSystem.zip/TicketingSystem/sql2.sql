drop table ticketing_create_master;
truncate ticketing_create_master;

create table ticketing_create_master( 
ticket_code int primary key auto_increment,
number varchar(40),
requester varchar(80),
requester_id varchar(40),
email varchar(40),
contact_number varchar(10),
configuration_item varchar(40),
priority int,
channel int,
type int,
category int,
subCategory int,
short_description varchar(100),	
description varchar(4000),
attachment varchar(1000),
state int,
on_hold_reason varchar(200),
vendor_ticket varchar(40),
assigned_to int,
assignment_group int,
resolution varchar(4000),
resolved_date datetime,
created_date datetime,
created_by varchar (80),
updated_date datetime,
update_by varchar(80)
);

insert into ticketing_create_master(requester,email,configuration_item,channel,type,
category,subCategory,short_description,description,attachment,state,created_date)
values('shivam','rohit@ess.net.in','Rohit Sawant',1,1,1,101,'abc','abd',null,1,now());

-- change to assigned_to int
alter table ticketing_create_master
modify assigned_to int;

alter table ticketing_create_master
add column contact_number varchar(10) after email;

alter table ticketing_create_master
add column priority int after configuration_item;

alter table ticketing_create_master
modify assigned_to varchar(40) after ;

alter table ticketing_create_master
modify assignment_group int after assigned_to;
