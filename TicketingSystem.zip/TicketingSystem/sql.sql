use timesheet;

-- ************** Channel ********************
drop table ticketing_channel_master;
create table ticketing_channel_master(
channel_id int primary key auto_increment,
channel_name varchar(20) not null unique
);

insert into ticketing_channel_master values
(1,'Self'),
(2,'Email'),
(3,'Phone');

-- ************** State ********************
create table ticketing_state_master(
state_id int primary key auto_increment,
state_name varchar(20) not null unique
);

insert into ticketing_state_master values
(1,'New'),
(2,'In Progress'),
(3,'On Hold'),
(4,'Resolved'),
(5,'Closed'),
(6,'Cancelled');

-- ************** Priority ********************
truncate ticketing_priority_master;
create table ticketing_priority_master(
priority_id int primary key auto_increment,
priority_name varchar(20) not null unique
);

insert into ticketing_priority_master values
(1,'Medium'),
(2,'Low'),
(3,'High');

-- ************** Type ********************
create table ticketing_type_master(
type_id int primary key auto_increment,
type_name varchar(20) not null unique
);

insert into ticketing_type_master values
(1,'Service Request'),
(2,'Incident');

-- ************** Category ********************
drop table ticketing_category_master;
select * from ticketing_category_master;
create table ticketing_category_master(
category_id int primary key auto_increment,
category_name varchar(20) not null,
ugrp_code int
);

insert into ticketing_category_master values
(1,'Hardware',2),
(2,'Software',2),
(3,'Inquiry/Help',2),
(4,'Network',null);
update ticketing_category_master set ugrp_code = 2 where category_id = 3;
-- ************** Subcategory ********************
drop table ticketing_subcategory;
select * from timesheet.ticketing_subcategory;
create table ticketing_subcategory(
category_id int,
subcategory_id int primary key auto_increment,
subcategory_name varchar(20) not null,
CONSTRAINT fk_subcategory FOREIGN KEY (category_id) REFERENCES ticketing_category_master(category_id)  
);

insert into ticketing_subcategory values 
(1,101,'CPU'),
(1,102,'Memory'),
(1,103,'Disk'),
(1,104,'Keyboard'),
(1,105,'Touchpad'),
(1,106,'Mouse'),
(1,107,'Monitor'),
(1,108,'Down'),
(1,109,'Battery');

insert into ticketing_subcategory values
(2,201,'Email'),
(2,202,'Operating System'),
(2,203,'Other');

insert into ticketing_subcategory values
(3,301,'Email'),
(3,302,'Internal Application'),
(3,303,'Other');

insert into ticketing_subcategory values
(4,401,'IP'),
(4,402,'Wireless');


